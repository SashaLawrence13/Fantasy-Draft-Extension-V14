# Fantasy Draft Bridge — ESPN Extension v2

Manifest V3 Chrome extension that scrapes your ESPN draft room and feeds picks
+ league setup into the Fantasy Football Tracker, then highlights the tracker's
top recommendation back inside ESPN's player list.

## Architecture (Option A — chrome.storage message bus)

```
ESPN draft room                 chrome.storage.local              Tracker tab (github.io)
─────────────────               ────────────────────              ───────────────────────
content-espn.js                                                   content-tracker.js
  scrape picks  ───────────────►  ffb:picks  ───────────────────►  postMessage ESPN_PICK ─► page
  detect setup  ───────────────►  ffb:setup  ───────────────────►  postMessage ESPN_SETUP ─► page
  highlight   ◄───────────────── ffb:topRec ◄───────────────────  page posts TRACKER_REC ◄─┘
```

The two tabs never talk directly — they communicate only through
`chrome.storage.local`, which is push-based (`storage.onChanged`) and persists,
so refreshing either tab restores the last state. The tracker can live in its
own tab, its own window, or a second monitor.

## Files

| File | Role |
|------|------|
| `manifest.json` | MV3; storage + tabs perms; host perms for ESPN + the tracker domain; registers both content scripts |
| `content-espn.js` | Scrapes picks + setup from ESPN; highlights the top rec. MutationObserver + 4s safety poll, defensive selectors |
| `content-tracker.js` | Bridge on the tracker page: replays storage → `window.postMessage`, captures `TRACKER_REC` → storage |
| `background.js` | Seeds empty state; opens/focuses the tracker tab on request |
| `popup.html` / `popup.js` | Status (picks captured, top rec), manual setup override, reset |
| `highlight.css` | Pulsing yellow highlight on the recommended ESPN row |

## Install

1. `chrome://extensions` → enable **Developer mode**.
2. **Load unpacked** → select this `extension-v2/` folder.
3. Open `draft-tracker.html` (the patched copy — see below) on GitHub Pages.
4. Open your ESPN draft room. Picks should start flowing within a few seconds.

## ⚠ Tracker patch required

This build relies on a 3-line change already made to `draft-tracker.html`: the
render hook now also posts `TRACKER_REC` to **its own window** (not just a
parent iframe), so the bridge works when the tracker is in a standalone tab.
**Re-upload the patched `draft-tracker.html` to GitHub** or the live site won't
emit recommendations.

## Tuning the scraper (expect this)

ESPN's draft room is a React SPA and its class names are not stable, so the
selectors are educated guesses with text fallbacks. If picks aren't captured:

- Open the ESPN tab's DevTools console; look for `[FFB] ESPN bridge active`.
- Inspect a drafted-pick row and a player-list row, grab a stable attribute,
  and add it to the top of `PICK_ROW_SELECTORS` / `PLAYER_ROW_SELECTORS` in
  `content-espn.js`.
- The text-parsing fallbacks (overall number, position regex, team regex)
  usually catch names even when the structural selectors miss.

## Known limits

- **Setup auto-detect** is best-effort (scans page text for "10-team", "PPR",
  etc.). Use the popup's manual override for certainty — manual always wins.
- **Slot** isn't sent over the bridge: the tracker's `ESPN_SETUP` handler
  ignores a `slot` field. Enter your slot once in the tracker's setup wizard,
  or ask to add 3 lines to the tracker handler.
- **Highlight-only** by design — the extension never clicks ESPN's Draft button.
