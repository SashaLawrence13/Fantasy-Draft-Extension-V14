// ============================================================
// background.js — minimal service worker.
// Option A keeps almost all logic in the two content scripts (they talk
// through chrome.storage.local directly), so the worker only seeds empty
// state on install and opens/focuses the tracker tab on request.
// ============================================================

const TRACKER_URL =
  'https://sashalawrence13.github.io/Fantasy-Football-Tracker/draft-tracker.html';

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['ffb:picks'], data => {
    if (!Array.isArray(data['ffb:picks'])) {
      chrome.storage.local.set({ 'ffb:picks': [] });
    }
  });
});

// Popup asks us to open or focus the tracker tab.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'OPEN_TRACKER') {
    chrome.tabs.query({ url: 'https://*.github.io/Fantasy-Football-Tracker/*' }, tabs => {
      if (tabs.length) {
        chrome.tabs.update(tabs[0].id, { active: true });
        chrome.windows.update(tabs[0].windowId, { focused: true });
      } else {
        chrome.tabs.create({ url: TRACKER_URL });
      }
      sendResponse({ ok: true });
    });
    return true; // async response
  }
});
