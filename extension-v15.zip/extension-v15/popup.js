// popup.js — status panel + manual setup override.
const KEY = { setup: 'ffb:setup', picks: 'ffb:picks', topRec: 'ffb:topRec', slot: 'ffb:slot', reset: 'ffb:resetToken' };
const $ = id => document.getElementById(id);

function render(data) {
  const picks = Array.isArray(data[KEY.picks]) ? data[KEY.picks] : [];
  $('pickCount').textContent = picks.length;

  const setup = data[KEY.setup];
  $('setupState').textContent = setup
    ? `${setup.teams || '?'} team · ${(setup.scoring || 'auto').toUpperCase()} (${setup.source || 'detected'})`
    : '—';
  if (setup) {
    if (setup.teams) $('teams').value = setup.teams;
    if (setup.scoring) $('scoring').value = setup.scoring;
  }
  if (data[KEY.slot]) $('slot').value = data[KEY.slot];

  const rec = data[KEY.topRec];
  if (rec && rec.topPick) {
    $('recBox').style.display = 'block';
    $('recName').textContent = rec.topPick;
    $('recPos').textContent = rec.pos ? `(${rec.pos})` : '';
    $('recScore').textContent = rec.score != null ? ` · ${Number(rec.score).toFixed(1)}` : '';
  }
}

chrome.storage.local.get(Object.values(KEY), render);

$('openTracker').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'OPEN_TRACKER' }, () => window.close());
});

$('saveSetup').addEventListener('click', () => {
  const teams = parseInt($('teams').value, 10);
  const scoring = $('scoring').value || null;
  const slot = parseInt($('slot').value, 10);
  const setup = {
    teams: Number.isFinite(teams) ? teams : null,
    scoring,
    source: 'manual'
  };
  const patch = { [KEY.setup]: setup };
  if (Number.isFinite(slot)) patch[KEY.slot] = slot;
  chrome.storage.local.set(patch, () => {
    $('setupState').textContent =
      `${setup.teams || '?'} team · ${(setup.scoring || 'auto').toUpperCase()} (manual)`;
    if (Number.isFinite(slot)) {
      $('slotNote').textContent =
        `Slot ${slot} saved here, but the tracker ignores slot over the bridge — enter it once in the tracker's setup wizard.`;
    }
  });
});

$('reset').addEventListener('click', () => {
  // Bump the reset token too: without it the tracker tab keeps its old board
  // and its content script keeps its "already posted" memory, so clearing
  // storage alone visibly does nothing — the #1 "reset didn't work" trap.
  chrome.storage.local.set({ [KEY.picks]: [], [KEY.topRec]: null, [KEY.reset]: Date.now() }, () => {
    $('pickCount').textContent = '0';
    $('recBox').style.display = 'none';
  });
});
