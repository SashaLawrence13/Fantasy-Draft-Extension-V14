// ============================================================
// content-tracker.js — runs on the GitHub Pages tracker page
//   https://*.github.io/Fantasy-Football-Tracker/*
//
// A GitHub Pages page can't touch chrome.* APIs, so this content script
// is the bridge: it reads picks/setup the ESPN script wrote to
// chrome.storage.local and replays them INTO the page as the exact
// window.postMessage shapes the tracker already handles. It also catches
// the tracker's outbound TRACKER_REC and writes it back to storage so the
// ESPN script can highlight that player.
// ============================================================

(() => {
  'use strict';

  const KEY = { setup: 'ffb:setup', picks: 'ffb:picks', topRec: 'ffb:topRec',
                reset: 'ffb:resetToken' };

  // The tracker persists its whole state (players + picks + queue) under this
  // localStorage key. Content scripts share the page's origin, so we can edit
  // it directly to clear ONLY the picks/queue while keeping the loaded players.
  const TRACKER_LS_KEY = 'ff-draft-tracker-v1';
  // Last reset token this PAGE has honoured — lets a tracker tab that was
  // closed when a new draft started catch up on boot instead of keeping a
  // stale board that misaligns every subsequent pick.
  const RESET_SEEN_LS = 'ffb-reset-seen-v1';

  // The page's ESPN_PICK handler drops picks silently when no players are
  // loaded (findPlayerByName can't match). Delivering then would LOSE those
  // picks forever, so delivery waits until the tracker has a player pool.
  function trackerHasPlayers() {
    try {
      const o = JSON.parse(localStorage.getItem(TRACKER_LS_KEY));
      return !!(o && Array.isArray(o.players) && o.players.length);
    } catch (e) { return false; }
  }

  // Wipe the tracker's picks for a new draft, preserving loaded rankings, then
  // reload so the page boots from the cleaned state and re-replays fresh picks.
  function resetTracker(token) {
    try {
      const raw = localStorage.getItem(TRACKER_LS_KEY);
      if (raw) {
        const o = JSON.parse(raw);
        o.picks = [];
        o.queue = [];
        localStorage.setItem(TRACKER_LS_KEY, JSON.stringify(o));
      }
    } catch (e) { /* ignore */ }
    try { if (token != null) localStorage.setItem(RESET_SEEN_LS, String(token)); } catch (e) {}
    location.reload();
  }

  const pickKey = p => (p && p.overall != null)
    ? 'o' + p.overall
    : 'n' + String(p && p.player || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

  const postedPicks = new Set();
  let lastSetupSig = '';

  // Ordered delivery. The tracker numbers picks by ARRIVAL and derives each
  // player's team/slot from that number, so ONE out-of-order or missing pick
  // shifts every later pick onto the wrong team ("right at first, then drifts").
  // We therefore deliver strictly in contiguous draft order (1,2,3,…): a pick
  // with overall N is held in the buffer until N-1 has been delivered.
  // (A reset reloads the page, which re-inits these to a clean start.)
  let nextExpected = 1;
  const buffer = new Map();   // overall -> pick

  function postPick(p) {
    window.postMessage({
      type: 'ESPN_PICK',
      overall: p.overall ?? undefined,
      round: p.round ?? undefined,
      player: p.player,
      pos: p.pos || undefined,
      team: p.team || undefined
    }, '*');
  }

  function pushSetup(setup) {
    if (!setup) return;
    const sig = `${setup.teams}|${setup.scoring}`;
    if (sig === lastSetupSig) return;
    lastSetupSig = sig;
    const msg = { type: 'ESPN_SETUP' };
    if (setup.teams) msg.teams = setup.teams;
    if (setup.scoring) msg.scoring = setup.scoring;
    if (msg.teams || msg.scoring) window.postMessage(msg, '*');
  }

  let lastPicks = [];   // latest picks array seen, so the poller can retry delivery
  let lastDropWarn = 0; // throttle for the board-mismatch console errors
  let dupStreak = 0;    // consecutive polls with MORE board picks than delivered

  function pushPicks(picks) {
    if (!Array.isArray(picks)) return;
    lastPicks = picks;
    // HOLD everything until the tracker has players: the page drops picks it
    // can't match, and a dropped pick would be marked posted = lost forever.
    // The poller below retries once the user loads a sample/CSV.
    if (!trackerHasPlayers()) return;
    for (const p of picks) {
      if (!p || !p.player) continue;
      if (p.overall != null) {
        if (postedPicks.has('o' + p.overall)) continue;
        buffer.set(p.overall, p);                 // queue for in-order delivery
      } else {
        // League size unknown -> no overall. Best effort: post in arrival order.
        const k = pickKey(p);
        if (!postedPicks.has(k)) { postedPicks.add(k); postPick(p); }
      }
    }
    // Drain the buffer only while the next pick number is present — this
    // guarantees the tracker receives 1,2,3,… with no gaps or reordering.
    while (buffer.has(nextExpected)) {
      const p = buffer.get(nextExpected);
      buffer.delete(nextExpected);
      postedPicks.add('o' + nextExpected);
      postPick(p);
      nextExpected++;
    }
  }

  // ---- Initial replay: setup first, then picks in order ----------------
  chrome.storage.local.get([KEY.setup, KEY.picks, KEY.reset], data => {
    // Catch up on a reset that fired while this tab was closed (new draft
    // started): the saved board belongs to the OLD draft — clear it first or
    // every replayed pick lands N slots off.
    const token = data[KEY.reset];
    let seen = '';
    try { seen = localStorage.getItem(RESET_SEEN_LS) || ''; } catch (e) {}
    if (token != null && String(token) !== seen) { resetTracker(token); return; }

    pushSetup(data[KEY.setup]);
    pushPicks(data[KEY.picks]);
  });

  // ---- Live updates ----------------------------------------------------
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    // New-draft signal from the ESPN side: reset the tracker and reload.
    if (changes[KEY.reset]) { resetTracker(changes[KEY.reset].newValue); return; }
    if (changes[KEY.setup]) pushSetup(changes[KEY.setup].newValue);
    if (changes[KEY.picks]) pushPicks(changes[KEY.picks].newValue);
  });

  // ---- Visible board-mismatch alert ---------------------------------------
  // v12 only logged dropped picks to the console, which nobody watches during
  // a live draft (Jul 3: the deployed page silently dropped 3 "Jr." picks and
  // the shifted board wasn't noticed until rounds later). Put it ON the page.
  // v14: also alert on MORE picks than delivered — an outdated page duplicates
  // every redelivered pick when the tracker tab is reloaded mid-draft.
  function showDropBanner(text) {
    let b = document.getElementById('ffb-drop-banner');
    if (!b) {
      b = document.createElement('div');
      b.id = 'ffb-drop-banner';
      b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:2147483647;' +
        'background:#c62828;color:#fff;font:bold 15px/1.45 -apple-system,Helvetica,sans-serif;' +
        'padding:10px 16px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.4);';
      document.documentElement.appendChild(b);
    }
    b.textContent = text;
  }
  function removeDropBanner() {
    const b = document.getElementById('ffb-drop-banner');
    if (b) b.remove();
  }

  // ---- Retry delivery once players exist / a gap fills -------------------
  // Cheap and idempotent: pushPicks dedupes via postedPicks, so re-offering
  // the same array never double-posts.
  setInterval(() => {
    if (lastPicks.length && trackerHasPlayers()) pushPicks(lastPicks);

    // Board-count check: with the up-to-date tracker page, the page's pick
    // count always equals the last delivered overall. FEWER means the page
    // silently DROPPED picks (old matcher / pool gaps); MORE means it
    // DUPLICATED picks (outdated page reloaded mid-draft re-logs every
    // redelivered pick). Both misalign the board — say so ON the page.
    const delivered = nextExpected - 1;
    if (delivered > 0) {
      let pageCount = 0;
      try {
        const o = JSON.parse(localStorage.getItem(TRACKER_LS_KEY));
        pageCount = (o && Array.isArray(o.picks)) ? o.picks.length : 0;
      } catch (e) {}
      if (pageCount < delivered) {
        dupStreak = 0;
        showDropBanner('⚠ DRAFT BOARD IS WRONG: this page dropped ' + (delivered - pageCount) +
          ' of ' + delivered + ' picks, so every pick after the first drop is on the wrong team. ' +
          'This page is running an OLD draft-tracker.html — upload the latest one from the ' +
          'Fantasy Draft folder to GitHub, then reload.');
        if (Date.now() - lastDropWarn > 30000) {
          lastDropWarn = Date.now();
          console.error(`[FFB] Tracker page DROPPED ${delivered - pageCount} of ${delivered} delivered pick(s) — ` +
            'its player pool could not match them, so the board is misaligned. ' +
            'Upload the latest draft-tracker.html to GitHub Pages.');
        }
      } else if (pageCount > delivered) {
        // Give boot-time catch-up a few ticks before alarming: right after a
        // reload the page already has all saved picks while `delivered` is
        // still climbing back up through the replay.
        dupStreak++;
        if (dupStreak >= 5) {
          showDropBanner('⚠ DRAFT BOARD IS WRONG: it shows ' + pageCount + ' picks but only ' +
            delivered + ' were drafted — picks got DUPLICATED (this page is running an outdated ' +
            'draft-tracker.html and the tab was reloaded mid-draft). Upload the latest ' +
            'draft-tracker.html from the Fantasy Draft folder to GitHub, then reload.');
          if (Date.now() - lastDropWarn > 30000) {
            lastDropWarn = Date.now();
            console.error(`[FFB] Tracker page has ${pageCount} picks but only ${delivered} were delivered — ` +
              'duplicated picks (outdated page + mid-draft reload). Upload the latest draft-tracker.html.');
          }
        }
      } else {
        dupStreak = 0;
        removeDropBanner();
      }
    }
  }, 1000);

  // ---- Outbound: capture TRACKER_REC the page posts to its own window ---
  window.addEventListener('message', e => {
    const msg = e.data;
    if (!msg || typeof msg !== 'object' || msg.type !== 'TRACKER_REC') return;
    chrome.storage.local.set({
      [KEY.topRec]: {
        topPick: msg.topPick,
        pos: msg.pos,
        score: msg.score,
        ts: Date.now()
      }
    });
  });

  console.log('[FFB] Tracker bridge active');
})();
