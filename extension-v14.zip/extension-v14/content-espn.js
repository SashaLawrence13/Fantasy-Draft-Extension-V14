// ============================================================
// content-espn.js — runs on fantasy.espn.com draft rooms.
//
// Responsibilities (Option A architecture):
//   1. Scrape new picks from the draft-history list  -> chrome.storage.local
//   2. Best-effort detect league setup (teams, scoring) -> chrome.storage.local
//   3. Read the tracker's top recommendation back from storage and
//      highlight that player in ESPN's available-player list.
//
// ESPN's draft room is a React SPA, so the DOM is rebuilt constantly.
// We use a debounced MutationObserver plus a slow interval poll as a
// safety net, and a battery of candidate selectors with text fallbacks
// because ESPN's class names are not stable.
// ============================================================

(() => {
  'use strict';

  const KEY = { setup: 'ffb:setup', picks: 'ffb:picks', topRec: 'ffb:topRec',
                league: 'ffb:leagueId', reset: 'ffb:resetToken',
                slotTeams: 'ffb:slotTeams' };

  // ---- NFL teams (for parsing the team code out of a row) ------------
  const TEAMS = ['ARI','ATL','BAL','BUF','CAR','CHI','CIN','CLE','DAL','DEN',
    'DET','GB','HOU','IND','JAX','JAC','KC','LV','LAC','LAR','LA','MIA','MIN',
    'NE','NO','NYG','NYJ','PHI','PIT','SF','SEA','TB','TEN','WAS','WSH'];
  const TEAM_RE = new RegExp('\\b(' + TEAMS.join('|') + ')\\b');
  const POS_RE  = /\b(QB|RB|WR|TE|D\/?ST|DEF|K|PK)\b/i;

  const normPos = p => {
    if (!p) return '';
    const u = p.toUpperCase().replace(/\s+/g, '');
    if (u === 'DST' || u === 'D/ST') return 'DEF';
    if (u === 'PK') return 'K';
    return u;
  };
  const normName = s => String(s || '').toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ').trim();

  // ============================================================
  // 1. PICK SCRAPING  (reads the always-visible "Picks" side panel)
  // ============================================================
  // The right-hand Picks panel is the reliable source: each entry is
  // self-labelled, e.g. "A.J. Brown / NE WR" + "R3, P8 - Mayfield of Dreams".
  // It's always present regardless of which centre tab is open, and unlike the
  // Pick History table it carries the round + pick-in-round INLINE. We anchor
  // on the player-name link and climb to the smallest ancestor that also
  // contains a "R#, P#" tag — that ancestor is exactly one pick's card.
  // Anything without a nearby R#/P# tag (available list, roster, queue, top
  // bar) is correctly ignored.

  // VERIFIED against a live 10-team mock draft (captured all 160 picks in order).
  // Each pick is an <li class="...pick-message__container...">, whose text reads
  // "Name / TEAM POS" immediately followed by "R#, P# - <fantasy team>", e.g.
  //   "Ja'Marr Chase / CIN WRR1, P1 - pstol plays"
  // (note "WR" runs straight into "R1" — hence NO word boundary before R).
  // We iterate those li's directly. The available-players list also uses
  // .playerinfo__playername but has no pick-message li and no R#/P#, so it is
  // excluded automatically.

  // R<round> ... P<pick-in-round>. NO leading \b — ESPN concatenates the
  // position into it ("WR"+"R1" => "WRR1"), so a boundary before R never matches.
  const ROUNDPICK_RE = /R\s*(\d{1,2})[\s,.:·•\-]*P\s*(\d{1,2})\b/i;

  // Smallest ancestor (within maxUp) whose text contains a R#/P# tag.
  function findPickCard(el, maxUp = 8) {
    let node = el;
    for (let i = 0; i < maxUp && node; i++) {
      if (ROUNDPICK_RE.test((node.textContent || '').replace(/\s+/g, ' '))) return node;
      node = node.parentElement;
    }
    return null;
  }

  // A stable key so we don't re-emit the same pick.
  const pickKey = p => (p.overall != null ? 'o' + p.overall : 'n' + normName(p.player));

  // ---- SNAKE-ORDER TEAM CHECK ----------------------------------------
  // In a snake draft the team on the clock is a pure function of the pick
  // number, so the fantasy-team name on each feed row ("… R2, P3 - <team>")
  // can validate — and repair — the R#/P# text, which is the flakier signal.
  // Round 1 defines the map: pick N = slot N.
  let slotTeams = {};   // slot -> normalized fantasy-team name (persisted)
  const FANTEAM_RE = /R\s*\d{1,2}[\s,.:·•\-]*P\s*\d{1,2}\b\s*[-–—]\s*(.+)$/i;

  function teamNamesMatch(a, b) {
    if (!a || !b) return false;
    if (a === b) return true;
    // ESPN truncates long team names in the feed — accept a unique prefix.
    return (a.length >= 4 && b.startsWith(a)) || (b.length >= 4 && a.startsWith(b));
  }

  function findSlotByTeam(teamNorm, teams) {
    let exact = 0, fuzzy = 0, fuzzyCount = 0;
    for (let s = 1; s <= teams; s++) {
      const t = slotTeams[s];
      if (!t) continue;
      if (t === teamNorm) { if (exact) return 0; exact = s; }
      else if (teamNamesMatch(t, teamNorm)) { fuzzy = s; fuzzyCount++; }
    }
    if (exact) return exact;
    return fuzzyCount === 1 ? fuzzy : 0;   // ambiguous -> don't guess
  }

  function scrapePicks(teamsHint) {
    // First pass: read every pick's round / pick-in-round / player / team.
    const raw = [];
    const lis = document.querySelectorAll('li[class*="pick-message"], li[class*="pick__message"]');
    for (const li of lis) {
      const text = (li.textContent || '').replace(/\s+/g, ' ');
      const rp = text.match(ROUNDPICK_RE);
      if (!rp) continue;

      // Name: prefer the dedicated span, else the text before the "/".
      let name = '';
      const span = li.querySelector('.playerinfo__playername');
      if (span) name = (span.textContent || '').trim();
      if (!name) name = (text.split('/')[0] || '').trim();
      if (!name || name.split(/\s+/).length < 2) continue;

      const round = parseInt(rp[1], 10);
      const pir   = parseInt(rp[2], 10);
      const tp = text.match(new RegExp('\\b(' + TEAMS.join('|') + ')\\b\\s*(QB|RB|WR|TE|D\\/?ST|DEF|K|PK)', 'i'));
      // Announcements ("Team X is on the clock R2, P5") have no player-name
      // span and no "NFL team + position" pair — never let one occupy a slot.
      if (!span && !tp) continue;
      const ftm = text.match(FANTEAM_RE);
      raw.push({ round, pir, player: name, pos: tp ? normPos(tp[2]) : '',
                 team: tp ? tp[1].toUpperCase() : '', fan: ftm ? normName(ftm[1]) : '' });
    }

    // Detect league size FROM THE DATA (highest pick-in-round seen) so the
    // overall pick number is computed correctly even if the popup's team count
    // is wrong/unset. A round-1 pick's overall == its pir regardless, and by the
    // time any round-2 pick exists round 1 is complete, so max-pir == teams.
    let teams = 0;
    for (const r of raw) if (r.pir > teams) teams = r.pir;
    if (teams < 4) teams = teamsHint || 10;

    // Build the slot -> team map from round 1 (round-1 pick N is slot N).
    let mapGrew = false;
    for (const r of raw) {
      if (r.round === 1 && r.fan && !slotTeams[r.pir]) {
        slotTeams[r.pir] = r.fan;
        mapGrew = true;
      }
    }
    if (mapGrew) chrome.storage.local.set({ [KEY.slotTeams]: slotTeams });
    const mapComplete = Object.keys(slotTeams).length >= teams;

    const seen = new Map();
    for (const r of raw) {
      let pir = r.pir;
      // From round 2 on, the R#/P# text must agree with WHO made the pick;
      // on mismatch derive the pick-in-round from the team's slot instead.
      if (r.round > 1 && mapComplete && r.fan) {
        const expSlot = (r.round % 2 === 1) ? pir : teams - pir + 1;
        if (!teamNamesMatch(slotTeams[expSlot], r.fan)) {
          const s = findSlotByTeam(r.fan, teams);
          if (!s) continue;   // team unknown — hold this row, don't guess
          pir = (r.round % 2 === 1) ? s : teams - s + 1;
          console.info(`[FFB] R${r.round} text said P${r.pir} but that team drafts at P${pir} — corrected via team name.`);
        }
      }
      const overall = (r.round - 1) * teams + pir;
      const p = { overall, round: r.round, pir, player: r.player, pos: r.pos, team: r.team };
      seen.set(pickKey(p), p);
    }
    return Array.from(seen.values());
  }

  // ============================================================
  // 2. SETUP DETECTION (best effort; popup override always wins)
  // ============================================================

  function detectSetup() {
    const body = (document.body.textContent || '').replace(/\s+/g, ' ');
    let teams = null, scoring = null;

    const t = body.match(/(\d{1,2})\s*-?\s*team/i);
    if (t) { const n = parseInt(t[1], 10); if (n >= 4 && n <= 20) teams = n; }

    if (/\bppr\b/i.test(body) && /half|0\.5/i.test(body)) scoring = 'half';
    else if (/half[\s-]?ppr|0\.5\s*ppr/i.test(body)) scoring = 'half';
    else if (/\bppr\b/i.test(body)) scoring = 'ppr';
    else if (/6\s*pt|6-?point|pp6/i.test(body)) scoring = 'pp6';
    else if (/standard|non[\s-]?ppr/i.test(body)) scoring = 'std';

    if (teams == null && scoring == null) return null;
    return { teams, scoring };
  }

  // ============================================================
  // 3. WRITE TO STORAGE
  // ============================================================

  // All read-modify-write storage ops go through one promise chain: the
  // observer (rAF) and the 4s backup poll can otherwise interleave get/set
  // and resurrect picks that a reset just cleared.
  let writeChain = Promise.resolve();

  function publishPicks(picks) {
    if (!picks.length) return;
    writeChain = writeChain.then(() => new Promise(resolve => {
      chrome.storage.local.get(KEY.picks, data => {
        const existing = Array.isArray(data[KEY.picks]) ? data[KEY.picks] : [];
        const have = new Set(existing.map(pickKey));
        const additions = picks.filter(p => !have.has(pickKey(p)));
        if (!additions.length) { resolve(); return; }
        // Keep order: ESPN history is newest-first or oldest-first depending on
        // the view; sort by overall when we have it so the tracker replays in order.
        const merged = existing.concat(additions);
        merged.sort((a, b) => (a.overall ?? 1e9) - (b.overall ?? 1e9));
        chrome.storage.local.set({ [KEY.picks]: merged }, () => resolve());
      });
    })).catch(() => {});
  }

  function publishSetup() {
    const detected = detectSetup();
    if (!detected) return;
    chrome.storage.local.get(KEY.setup, data => {
      const cur = data[KEY.setup];
      if (cur && cur.source === 'manual') return;   // don't clobber popup input
      const next = {
        teams: detected.teams ?? cur?.teams ?? null,
        scoring: detected.scoring ?? cur?.scoring ?? null,
        source: 'detected'
      };
      if (!cur || cur.teams !== next.teams || cur.scoring !== next.scoring) {
        chrome.storage.local.set({ [KEY.setup]: next });
      }
    });
  }

  // ============================================================
  // 4. HIGHLIGHT THE TRACKER'S TOP REC IN ESPN'S PLAYER LIST
  // ============================================================

  const HL_CLASS = 'ffb-rec-highlight';

  // Candidate selectors for rows in the *available players* table.
  const PLAYER_ROW_SELECTORS = [
    '[class*="player-column__athlete"]',
    'tr[class*="Table__TR"]',
    '[class*="PlayerRow"]',
    '[data-test="player-row"]',
    '.full-projection-table tbody tr',
    'table tbody tr'
  ];

  function getPlayerRows() {
    for (const sel of PLAYER_ROW_SELECTORS) {
      const rows = document.querySelectorAll(sel);
      if (rows.length) return Array.from(rows);
    }
    return [];
  }

  function nameMatches(rowText, target) {
    const parts = String(target || '').replace(/[.,]/g, '').split(/\s+/).filter(Boolean);
    if (parts.length < 2) return false;
    const fi = parts[0][0].toLowerCase();
    const last = parts[parts.length - 1].toLowerCase();
    const rt = rowText.toLowerCase();
    // last name present AND a same-first-initial token present
    if (!rt.includes(last)) return false;
    return rt.split(/\s+/).some(w => w[0] === fi);
  }

  let lastHighlit = null;
  function applyHighlight(topRec) {
    if (!topRec || !topRec.topPick) return;
    if (lastHighlit) lastHighlit.classList.remove(HL_CLASS);
    lastHighlit = null;

    // Fast path: ESPN names live in a[title]. Highlight a DRAFTABLE match —
    // i.e. one with no "R#, P#" pick tag nearby (that would be an already
    // drafted entry in the Picks panel / Pick History).
    const links = document.querySelectorAll('.player-column a[title], a[title]');
    for (const a of links) {
      if (nameMatches(a.getAttribute('title') || '', topRec.topPick)) {
        if (findPickCard(a)) continue;             // already drafted — not actionable
        const target = a.closest('[role="row"]') ||
          a.closest('[class*="player-column"]') ||
          a.closest('tr') || a.parentElement;
        if (target) { target.classList.add(HL_CLASS); lastHighlit = target; return; }
      }
    }

    // Fallback: scan whole rows by text.
    for (const row of getPlayerRows()) {
      const txt = (row.textContent || '').replace(/\s+/g, ' ').trim();
      if (nameMatches(txt, topRec.topPick)) {
        const target = row.closest('tr') || row;
        target.classList.add(HL_CLASS);
        lastHighlit = target;
        return;
      }
    }
  }

  let currentTopRec = null;
  chrome.storage.local.get(KEY.topRec, d => { currentTopRec = d[KEY.topRec] || null; applyHighlight(currentTopRec); });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[KEY.topRec]) return;
    currentTopRec = changes[KEY.topRec].newValue || null;
    applyHighlight(currentTopRec);
  });

  // ============================================================
  // SCHEDULER — debounced observer + safety-net poll
  // ============================================================

  // Track team count so we can compute each pick's overall number.
  let currentTeams = null;
  chrome.storage.local.get([KEY.setup, KEY.slotTeams], d => {
    currentTeams = d[KEY.setup]?.teams || null;
    slotTeams = d[KEY.slotTeams] || {};   // survive a mid-draft tab reload
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes[KEY.setup]) {
      currentTeams = changes[KEY.setup].newValue?.teams || null;
    }
  });

  // ---- AUTO-RESET on a new draft -------------------------------------
  // Each ESPN draft has its own leagueId in the URL. When it changes, this is a
  // new draft, so we wipe the stale picks and bump a reset token that
  // content-tracker watches (it clears the tracker's saved picks + reloads).
  // Only fires while actually in a draft room, so browsing other pages of the
  // same league mid-draft never triggers it.
  let lastKnownLeague = null;
  function currentDraftLeagueId() {
    if (!/\/football\/draft/.test(location.pathname)) return null;
    const m = location.href.match(/leagueId=(\d+)/);
    return m ? m[1] : null;
  }
  function maybeAutoReset() {
    const lg = currentDraftLeagueId();
    if (!lg || lg === lastKnownLeague) return;
    // Same chain as publishPicks: a reset must not interleave with a pick write.
    writeChain = writeChain.then(() => new Promise(resolve => {
      chrome.storage.local.get(KEY.league, d => {
        const prev = d[KEY.league];
        if (prev && prev !== lg) {
          // NEW draft -> clear stale picks + slot map, signal the tracker to reset.
          slotTeams = {};
          chrome.storage.local.set({
            [KEY.picks]: [], [KEY.topRec]: null, [KEY.slotTeams]: {},
            [KEY.league]: lg, [KEY.reset]: Date.now()
          }, () => resolve());
        } else if (prev !== lg) {
          chrome.storage.local.set({ [KEY.league]: lg }, () => resolve());   // first draft seen
        } else {
          resolve();
        }
        lastKnownLeague = lg;
      });
    })).catch(() => {});
  }

  function tick() {
    try {
      maybeAutoReset();
      publishPicks(scrapePicks(currentTeams));
      publishSetup();
      applyHighlight(currentTopRec);   // re-apply after ESPN re-renders the list
    } catch (e) { /* never let a bad render kill the loop */ }
  }

  let raf = 0;
  const observer = new MutationObserver(() => {
    if (raf) return;
    raf = requestAnimationFrame(() => { raf = 0; tick(); });
  });
  observer.observe(document.body, { childList: true, subtree: true });

  setInterval(tick, 4000);   // backup poll
  tick();                    // initial pass

  console.log('[FFB] ESPN bridge active');
})();
